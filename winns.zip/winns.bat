@echo off
start /WAIT %~dp0\winntsetup\winntsetup.exe